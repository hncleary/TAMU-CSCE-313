compiles with supplied makefile "make"
runs with ./shell
